import AVFoundation
import Speech
import SwiftUI

// MARK: - API Modelleri ve İstemci
struct UserTurn: Encodable {
    let session_id: String
    let user_text: String
    let selected_department: String?
}

struct BotTurn: Decodable {
    let session_id: String
    let next_prompt: String
    let need_more: Bool
    let options: [String]?
    let matched_diseases: [String]
    let user_symptoms: [String]
    let step: String
}

enum DialogAPIError: Error { case invalid(Int), decoding(Error), message(String) }

enum DialogAPI {
    // ---- 1) HOST & PORT (cihaz/sim ayrımı) ----
    #if targetEnvironment(simulator)
    private static let HOST = "http://127.0.0.1"    // Simulator
    #else
    private static let HOST = "http://192.168.1.19" // 
    #endif
    private static let PORT = 8001                  // API hangi portta dinliyorsa 8000/8001

    private static let API_V0 = "\(HOST):\(PORT)/api/v0"
    private static let BASE   = API_V0 + "/medicine" // FastAPI: prefix="/api/v0/medicine"

    // ---- 2) İstek ----
    static func sendTurn(sessionID: String,
                         userText: String,
                         selectedDepartment: String? = nil) async throws -> BotTurn {
        let url = URL(string: "\(BASE)/dialog/turn")!
        print("Dialog URL =>", url.absoluteString)   // Konsolda tam URL’yi gör

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body = UserTurn(session_id: sessionID, user_text: userText, selected_department: selectedDepartment)
        req.httpBody = try JSONEncoder().encode(body)

        do {
            let (d, r) = try await URLSession.shared.data(for: req)
            let code = (r as? HTTPURLResponse)?.statusCode ?? -1
            guard (200..<300).contains(code) else {
                if let m = try? JSONDecoder().decode([String:String].self, from: d),
                   let detail = m["detail"] {
                    throw DialogAPIError.message("HTTP \(code): \(detail)")
                }
                throw DialogAPIError.invalid(code)
            }
            return try JSONDecoder().decode(BotTurn.self, from: d)
        } catch let e as URLError {
            throw DialogAPIError.message("URLError \(e.code.rawValue): \(e.localizedDescription)")
        } catch {
            throw error
        }
    }
}

// MARK: - ViewModel (ANA THREAD)
@MainActor
final class MedAsistanSpeech: NSObject, ObservableObject, AVSpeechSynthesizerDelegate {
    @Published var transcript = ""
    @Published var isListening = false
    @Published var isSpeaking  = false
    @Published var sessionID = UUID().uuidString
    @Published var lastBot: BotTurn?
    @Published var errorText: String?

    private let synthesizer = AVSpeechSynthesizer()
    private let audioEngine  = AVAudioEngine()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?

    // ✅ TR yoksa fallback tanıyıcı
    private lazy var recognizer: SFSpeechRecognizer? = {
        SFSpeechRecognizer(locale: Locale(identifier: "tr-TR"))
        ?? SFSpeechRecognizer(locale: Locale(identifier: Locale.current.identifier))
        ?? SFSpeechRecognizer()
    }()

    // ✅ final beklemek için
    private var finalizeWorkItem: DispatchWorkItem?
    private var finalResultArrived = false

    private var started = false

    override init() {
        super.init()
        synthesizer.delegate = self
    }

    func startFlow() {
        guard !started else { return }
        started = true
        Task { await requestPermissionsAndGreet() }
    }

    private func requestPermissionsAndGreet() async {
        let micGranted = await AVAudioApplication.requestRecordPermission()
        guard micGranted else { self.transcript = "Mikrofon izni gerekli."; return }

        let auth = await withCheckedContinuation {
            (c: CheckedContinuation<SFSpeechRecognizerAuthorizationStatus, Never>) in
            SFSpeechRecognizer.requestAuthorization { c.resume(returning: $0) }
        }
        guard auth == .authorized, recognizer?.isAvailable == true else {
            self.transcript = "Tanıyıcı hazır değil."
            return
        }
        speak("Hoş geldiniz. Ben Med Asistan. Hastalık belirtileriniz nelerdir?")
    }

    // MARK: - TTS
    func speak(_ text: String) {
        // Kayıtla çakışmasın
        stopListening()

        let session = AVAudioSession.sharedInstance()
        do {
            try session.setActive(false)
            try session.setCategory(.playback, mode: .default, options: [.duckOthers])
            try session.setActive(true, options: .notifyOthersOnDeactivation)
        } catch { self.errorText = error.localizedDescription }

        let u = AVSpeechUtterance(string: text)
        if let tr = AVSpeechSynthesisVoice(language: "tr-TR") { u.voice = tr }
        isSpeaking = true
        synthesizer.speak(u)
    }

    func speechSynthesizer(_ s: AVSpeechSynthesizer, didFinish u: AVSpeechUtterance) {
        isSpeaking = false
        beginListening()
    }

    // MARK: - STT
    func beginListening() {
        guard isListening == false else { return }

        // Temiz başla
        if audioEngine.isRunning {
            audioEngine.stop()
            audioEngine.inputNode.removeTap(onBus: 0)
        }
        audioEngine.reset()
        let engine = audioEngine

        // Kayıt oturumu
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setActive(false)
            try session.setCategory(.record, mode: .measurement, options: [.duckOthers])
            try session.setActive(true, options: .notifyOthersOnDeactivation)
        } catch { self.errorText = "Session: \(error.localizedDescription)"; return }

        // Request
        let req = SFSpeechAudioBufferRecognitionRequest()
        req.shouldReportPartialResults = true
        req.requiresOnDeviceRecognition = false   // TR genelde online
        req.taskHint = .dictation
        self.request = req

        guard let recognizer, recognizer.isAvailable else {
            self.errorText = "Tanıyıcı uygun değil."
            return
        }

        // Donanım formatıyla tap
        let input = engine.inputNode
        let hwFormat = input.outputFormat(forBus: 0)
        input.removeTap(onBus: 0)
        input.installTap(onBus: 0, bufferSize: 2048, format: hwFormat) { [weak self] buffer, _ in
            self?.request?.append(buffer)
        }

        engine.prepare()
        do {
            try engine.start()
        } catch {
            input.removeTap(onBus: 0)
            self.errorText = "Engine: \(error.localizedDescription)"
            return
        }

        isListening = true
        finalResultArrived = false

        task = recognizer.recognitionTask(with: req) { [weak self] result, err in
            guard let self else { return }
            if let t = result?.bestTranscription.formattedString, !t.isEmpty {
                self.transcript = t
            }
            if err != nil || (result?.isFinal ?? false) {
                self.finalResultArrived = true
                self.cancelRecognitionCore()
                Task { await self.sendCurrentTranscript() }
            }
        }
    }

    // ✅ "Durdur": final bekler, task'i iptal etmez
    func finishListening() {
        if audioEngine.isRunning {
            audioEngine.stop()
            audioEngine.inputNode.removeTap(onBus: 0)
        }
        request?.endAudio()
        isListening = false

        // 1.5 sn içinde final gelmezse eldeki metni gönder
        finalizeWorkItem?.cancel()
        let wi = DispatchWorkItem { [weak self] in
            guard let self else { return }
            if self.finalResultArrived == false {
                Task { await self.sendCurrentTranscript() }
                self.cancelRecognitionCore()
            }
        }
        finalizeWorkItem = wi
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5, execute: wi)
    }

    // Tam iptal (TTS'e geçerken vs.)
    func stopListening() {
        if audioEngine.isRunning {
            audioEngine.stop()
            audioEngine.inputNode.removeTap(onBus: 0)
        }
        request?.endAudio()
        cancelRecognitionCore()
        audioEngine.reset()
        isListening = false
    }

    private func cancelRecognitionCore() {
        finalizeWorkItem?.cancel(); finalizeWorkItem = nil
        task?.cancel(); task = nil
        request = nil
    }

    // MARK: - Sunucuya gönder
    func sendCurrentTranscript() async {
        let text = transcript.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        do {
            let bot = try await DialogAPI.sendTurn(sessionID: sessionID,
                                                   userText: text,
                                                   selectedDepartment: nil)
            self.lastBot = bot
            self.transcript = ""
            speak(bot.next_prompt)
        } catch let DialogAPIError.message(msg) {
            self.errorText = msg
            speak("Üzgünüm, sunucuya bağlanamadım.")
        } catch let DialogAPIError.invalid(code) {
            self.errorText = "HTTP \(code) — endpoint ya da prefix yanlış."
            speak("Üzgünüm, sunucuya bağlanamadım.")
        } catch {
            self.errorText = (error as NSError).localizedDescription
            speak("Üzgünüm, sunucuya bağlanamadım.")
        }

    }

    func chooseDepartment(_ dep: String) async {
        do {
            let bot = try await DialogAPI.sendTurn(sessionID: sessionID,
                                                   userText: "",
                                                   selectedDepartment: dep)
            self.lastBot = bot
            speak(bot.next_prompt)
        } catch {
            self.errorText = error.localizedDescription
            speak("Bölüm seçimi gönderilemedi.")
        }
    }
}

// MARK: - View
struct MedAsistanView: View {
    @StateObject private var vm = MedAsistanSpeech()

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Med Asistan").font(.largeTitle).bold()

            if let e = vm.errorText {
                Text(e).foregroundColor(.red)
            }

            TextField("Belirtilerinizi söyleyin veya yazın…", text: $vm.transcript)
                .textFieldStyle(.roundedBorder)

            HStack {
                Button("Konuş") { vm.beginListening() }
                    .disabled(vm.isSpeaking || vm.isListening)
                Button("Durdur") { vm.finishListening() }               // ✅
                Button("Gönder (yazılı)") { Task { await vm.sendCurrentTranscript() } }
            }

            if let ops = vm.lastBot?.options, !ops.isEmpty {
                Text("Bölüm seçenekleri:").bold()
                ForEach(ops, id: \.self) { o in
                    Button(o) { Task { await vm.chooseDepartment(o) } }
                }
            }

            Spacer()
        }
        .padding()
        .onAppear { vm.startFlow() }
    }
}
